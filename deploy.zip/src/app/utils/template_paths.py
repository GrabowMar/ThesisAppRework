"""Template utilities."""

from flask import render_template

__all__ = ['render_template']
