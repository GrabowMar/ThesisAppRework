"""Service Locator Pattern
=========================

Centralized service registry for dependency injection.
Deprecated services (AnalyzerService, ContainerService, HuggingFaceService,
PortService) are no longer registered here.

All new services should reuse standardized exceptions from
`service_base` and keep side-effects (threads, external processes)
outside of the Flask request path when possible.
"""

from typing import Dict, Optional, TypeVar, TYPE_CHECKING
import logging
from flask import Flask

if TYPE_CHECKING:
    from .docker_manager import DockerManager
    from .docker_status_cache import DockerStatusCache
    from .model_service import ModelService
    from .generation_v2.service import GenerationService
    from .analysis_inspection_service import AnalysisInspectionService
    from .unified_result_service import UnifiedResultService
    from .report_service import ReportService
    from .health_service import HealthService
    from .task_execution_service import TaskExecutionService

T = TypeVar('T')


class ServiceLocator:
    """
    Central registry for application services.
    Implements dependency injection pattern for clean architecture.
    """
    
    _services: Dict[str, object] = {}
    _app: Optional[Flask] = None
    
    @classmethod
    def initialize(cls, app: Flask):
        """Initialize the service locator with Flask app context."""
        cls._app = app
        cls._services.clear()
        
        # Register core services
        cls._register_core_services(app)
    
    @classmethod
    def _register_core_services(cls, app: Flask):
        """Register all core application services."""
        # Import services here to avoid circular imports. Keep the list short.
        from .model_service import ModelService
        from .generation_v2 import get_generation_service

        try:
            from .health_service import HealthService
        except ImportError:
            HealthService = None

        try:
            from .docker_manager import DockerManager
        except ImportError:
            DockerManager = None

        try:
            from .docker_status_cache import DockerStatusCache
        except ImportError:
            DockerStatusCache = None

        try:
            from .analysis_inspection_service import AnalysisInspectionService
        except ImportError:  # pragma: no cover
            AnalysisInspectionService = None  # type: ignore

        try:
            from .unified_result_service import UnifiedResultService
        except ImportError:  # pragma: no cover
            UnifiedResultService = None  # type: ignore

        try:
            from .report_service import ReportService
        except ImportError:  # pragma: no cover
            ReportService = None  # type: ignore


        # Register available services
        cls.register('model_service', ModelService(app))
        
        try:
            cls.register('generation_service', get_generation_service())
        except Exception as e:  # pragma: no cover
            logging.warning(f"Failed to register generation service: {e}")

        # No registrations for removed legacy services
        if DockerManager:
            docker_mgr = DockerManager()
            cls.register('docker_manager', docker_mgr)
            # Register status cache with reference to docker manager
            if DockerStatusCache:
                cls.register('docker_status_cache', DockerStatusCache(docker_manager=docker_mgr))
        elif DockerStatusCache:
            # Register cache without docker manager (will fetch lazily)
            cls.register('docker_status_cache', DockerStatusCache())
        if AnalysisInspectionService:
            cls.register('analysis_inspection_service', AnalysisInspectionService())
        if UnifiedResultService:
            cls.register('unified_result_service', UnifiedResultService())
        if ReportService:
            cls.register('report_service', ReportService())
        if HealthService:
            cls.register('health_service', HealthService())

        # Best-effort: ensure PortConfiguration is populated from misc/port_config.json
        # Only done outside tests to avoid slowing the suite.
        try:
            import os as _os
            is_testing = bool(app.config.get('TESTING')) or bool(_os.environ.get('PYTEST_CURRENT_TEST'))
            if not is_testing:
                from app.models import PortConfiguration  # type: ignore
                from app.extensions import db as _db  # lazy import to avoid cycles
                # Only populate if table appears empty
                if _db.session.query(PortConfiguration).count() == 0:
                    logger = logging.getLogger(__name__)
                    logger.info("PortConfiguration empty; attempting to load from misc/port_config.json ...")
                    try:
                        from .data_initialization import DataInitializationService
                        svc = DataInitializationService()
                        res = svc.load_port_config()
                        # Commit changes
                        _db.session.commit()
                        logger.info("Loaded %s port entries (created: %s, updated: %s)", res.get('loaded', 0), res.get('created', 0), res.get('updated', 0))
                    except Exception as _port_err:
                        logger.warning("Failed to auto-load port configuration: %s", _port_err)
        except Exception:
            # Non-fatal; continue startup
            pass
    
    @classmethod
    def register(cls, name: str, service: object):
        """Register a service with the locator."""
        cls._services[name] = service
    
    @classmethod
    def get(cls, name: str, default=None):
        """Get a service by name."""
        return cls._services.get(name, default)
    
    @classmethod
    def get_model_service(cls) -> Optional["ModelService"]:
        """Get the model service."""
        return cls.get('model_service')  # type: ignore[return-value]
    
    @classmethod
    def get_docker_manager(cls) -> Optional["DockerManager"]:
        """Get the Docker manager service."""
        return cls.get('docker_manager')  # type: ignore[return-value]
    
    @classmethod
    def get_docker_status_cache(cls) -> Optional["DockerStatusCache"]:
        """Get the Docker status cache service."""
        return cls.get('docker_status_cache')  # type: ignore[return-value]
    
    @classmethod
    def get_generation_service(cls) -> Optional["GenerationService"]:
        """Get the generation service."""
        return cls.get('generation_service')  # type: ignore[return-value]
    
    @classmethod
    def get_analysis_inspection_service(cls) -> Optional["AnalysisInspectionService"]:
        """Get the analysis inspection service."""
        return cls.get('analysis_inspection_service')  # type: ignore[return-value]

    @classmethod
    def get_unified_result_service(cls) -> Optional["UnifiedResultService"]:
        """Get the unified result service."""
        return cls.get('unified_result_service')  # type: ignore[return-value]

    @classmethod
    def get_health_service(cls) -> Optional["HealthService"]:
        """Get the health service."""
        return cls.get('health_service')  # type: ignore[return-value]
    
    @classmethod
    def get_report_service(cls) -> Optional["ReportService"]:
        """Get the report generation service."""
        return cls.get('report_service')  # type: ignore[return-value]
    
    @classmethod
    def get_task_execution_service(cls) -> Optional["TaskExecutionService"]:
        """Get the task execution service."""
        return cls.get('task_execution_service')  # type: ignore[return-value]
    
    @classmethod
    def clear(cls):
        """Clear all registered services (for testing)."""
        cls._services.clear()
        cls._app = None
