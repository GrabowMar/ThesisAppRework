"""Error handling package initialization."""
from .handlers import register_error_handlers  # noqa: F401
