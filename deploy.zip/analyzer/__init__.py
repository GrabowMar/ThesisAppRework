"""Analyzer package root for service shared modules."""
