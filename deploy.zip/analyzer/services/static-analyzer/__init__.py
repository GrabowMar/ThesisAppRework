"""Static analyzer service package."""
