#!/bin/bash
# Container startup helper
# This file serves as an entrypoint helper if needed
exec "$@"
